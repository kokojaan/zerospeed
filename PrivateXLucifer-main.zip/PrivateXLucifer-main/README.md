# 𝐀𝐑𝐊𝐇𝐀𝐌𝐱𝐆𝐎𝐃-𝐌𝐔𝐋𝐓𝐈𝐒𝐏𝐀𝐌-𝐁𝐎𝐓
## 🚀 Deploy on Heroku 

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/ChutiyaXpRo/PrivateXLucifer)

## String Session FOR  BOT AND IDS 


   - BOT STRING [![Run on Repl.it](https://repl.it/badge/github/YukkiBot/YukkiSpamBot)](https://replit.com/@hyperop6666/HYPER-SPAM-BOT-REPL#main.py)
   - IDS STRING [![Run on Repl.it](https://repl.it/badge/github/YukkiBot/YukkiSpamBot)](https://replit.com/@hyperop6666/HYPER-REPL#main.py)
